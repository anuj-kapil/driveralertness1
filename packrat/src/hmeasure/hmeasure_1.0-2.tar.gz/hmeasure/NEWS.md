# hmeasure 1.0-2

Updated license.

## Note fixes

- License did not have the right copyright holder name